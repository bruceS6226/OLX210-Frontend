export const environment = {
  production: true,
  //url: 'https://linkindustrias.com/',
  url: 'http://localhost:3000/',
  id_user: '1'
};
