export class TiposDocumento {
  constructor(
    public id_tipo_documento: number,
    public nombre_tipo_documento: string,
  ){}
}
