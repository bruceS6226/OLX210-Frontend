export class TiposUsuario {
  constructor(
    public id_tipo_usuario: number,
    public nombre_tipo_usuario: string,
  ){}
}
