export class ClasesUsuario {
  constructor(
    public id_clase_usuario: number,
    public nombre_clase_usuario: string,
  ){}
}
