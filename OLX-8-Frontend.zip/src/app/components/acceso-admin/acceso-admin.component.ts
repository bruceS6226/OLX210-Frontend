import { Component } from '@angular/core';

@Component({
  selector: 'app-acceso-admin',
  templateUrl: './acceso-admin.component.html',
  styleUrls: ['./acceso-admin.component.css']
})
export class AccesoAdminComponent {

}
