# Frontend del proyecto OLX8
## Pasos para Iniciar

En una terminal ejecuta el siguiente código:
```
git clone <URL del repositorio>
```

Navega a la Carpeta del Proyecto:

Ve a la carpeta del proyecto usando el siguiente comando:
```
cd <nombre de la carpeta del proyecto>
```
Instala las Dependencias:

Ejecuta el siguiente comando para instalar todas las dependencias:

```
npm install
```
Inicia el Servidor de Desarrollo:

Lanza la aplicación en tu navegador con el comando:
```
ng serve
```
Tu aplicación estará disponible en http://localhost:4200/.

¡Listo! Ahora estás listo para explorar y trabajar en el proyecto. ¡Diviértete desarrollando!